package com.tillster.newdiabetesapplication;

public class Product {

    private String burgerName;
    private String burgerPrice;

    public String getBurgerName() {
        return burgerName;
    }

    public void setBurgerName(String burgerName) {
        this.burgerName = burgerName;
    }


    public String getBurgerPrice() {
        return burgerPrice;
    }

    public void setBurgerPrice(String burgerPrice) {
        this.burgerPrice = burgerPrice;
    }


}
